import React from 'react';
import { View, Text } from 'react-native';

export default function Home() {
  return (
    <View style={{ padding: 20 }}>
      <Text>Welcome to H-Wallet Home</Text>
    </View>
  );
}