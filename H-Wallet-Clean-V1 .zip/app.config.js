export default {
  expo: {
    name: "H Wallet",
    slug: "h-wallet",
    version: "1.0.0",
    sdkVersion: "53.0.0",
    orientation: "portrait",
    platforms: ["android"],
    assetBundlePatterns: ["**/*"],
    android: {
      package: "com.hwallet.v1"
    },
    extra: {
      eas: {
        projectId: "423748b5-10a0-45a3-971a-1aea8f05ffeb"
      }
    }
  }
};